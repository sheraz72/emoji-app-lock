package com.app.sherazlock.mvp.contract;

import android.content.Context;

import com.app.sherazlock.base.BasePresenter;
import com.app.sherazlock.base.BaseView;
import com.app.sherazlock.model.CommLockInfo;
import com.app.sherazlock.mvp.p.LockMainPresenter;

import java.util.List;



public interface LockMainContract {
    interface View extends BaseView<Presenter> {

        void loadAppInfoSuccess(List<CommLockInfo> list);
    }

    interface Presenter extends BasePresenter {
        void loadAppInfo(Context context);

        void searchAppInfo(String search, LockMainPresenter.ISearchResultListener listener);

        void onDestroy();
    }
}
