package com.app.sherazlock.base;


public interface BasePresenter {
}
