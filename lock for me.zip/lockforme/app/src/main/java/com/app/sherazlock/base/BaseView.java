package com.app.sherazlock.base;


public interface BaseView<T extends BasePresenter> {
}
