package com.app.sherazlock.activities.about;

import android.os.Bundle;

import com.app.sherazlock.R;
import com.app.sherazlock.base.BaseActivity;



public class AboutMeActivity extends BaseActivity {
    @Override
    public int getLayoutId() {
        return R.layout.activity_about_me;
    }

    @Override
    protected void initViews(Bundle savedInstanceState) {

    }

    @Override
    protected void initData() {

    }

    @Override
    protected void initAction() {

    }
}
